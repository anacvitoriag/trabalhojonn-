#Alterando valores em uma lista
precos = [8.90, 5.20, 12.50, 4.30]
precos[1] = 5.80  
print("Lista final de preços:", precos)
