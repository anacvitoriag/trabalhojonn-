#Iterando sobre uma tupla categorias
categorias = ("Bebidas", "Limpeza", "Padaria", "Hortifruti")
for c in categorias:
    print(c)
