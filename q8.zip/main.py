#Conjunto elimina duplicatas
clientes = {"Ana", "Carlos", "Maria", "João", "Ana", "Beatriz"}
print("Clientes (sem repetição):", clientes
)

