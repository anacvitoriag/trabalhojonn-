#Acessando elementos da tupla loja
loja = ("Supermercado Alegria", "Avenida Brasil, 456", "Marcos Silva")
print("Endereço da loja:", loja[1])
