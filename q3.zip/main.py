#Ordenando uma lista
vendas = [320, 450, 390, 500, 410]
total = sum(vendas)
print("Total de vendas:", total)
