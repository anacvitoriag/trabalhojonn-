#Tupla com informações de produto
estoque = [25, 40, 15, 60, 30, 10]
estoque.sort()
print("Estoque em ordem crescente:", estoque)
