#Acessando elementos da tupla loja
produto = ("Chocolate", 9.75, 35)
print("Nome:", produto[0])
print("Preço:", produto[1])
print("Quantidade em estoque:", produto[2])
